function footer(){
    document.getElementById('footer').innerHTML = "<br><br><br><br><br><br><br><br><br><br><br>";
}
footer();