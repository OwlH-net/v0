#CentOS
yum -y install perl-libwww-perl perl-JSON libyaml-devel
wget https://files.molo.ch/builds/centos-7/moloch-2.2.2-1.x86_64.rpm
sudo rpm -i moloch-2.2.2-1.x86_64.rpm
