# OwlH-installer
OwlH tool to help deploy and update your owlh stuff.


Edit config.json file for: 

# TARGET: 
node

master

ui

# ACTION: 
install - create or overwrite target

update - update current target deployment 
