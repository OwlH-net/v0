cd /tmp
sudo yum -y install httpd mod_ssl php wget

sudo mkdir -p /var/www/owlh
suco chmod 755 /var/www/owlh/
sudo mkdir -p /tmp/owlhui

sudo cat > /etc/httpd/conf.d/owlh.conf <<\EOF
<VirtualHost *:80>
   ServerName master.owlh.net
   Redirect / https://localhost/
</VirtualHost>

<VirtualHost *:443>
        SSLEngine on
        SSLCertificateFile /usr/local/owlh/src/owlhmaster/conf/certs/ca.crt
        SSLCertificateKeyFile /usr/local/owlh/src/owlhmaster/conf/certs/ca.key
        <Directory /var/www/owlh>
           Header set Access-Control-Allow-Origin "*"
           DirectoryIndex index.html index.php
           AllowOverride All
        </Directory>
        DocumentRoot /var/www/owlh
        ServerName master.owlh.net
</VirtualHost>
EOF

sudo wget repo.owlh.net/current/owlhui.tar.gz
sudo tar -C /tmp/owlhui/ -zxvf /tmp/owlhui.tar.gz
sudo cp -rp /tmp/owlhui/* /var/www/owlh

export MYPUBIP=$(curl http://169.254.169.254/latest/meta-data/public-ipv4)
sed -i "s/<MASTERIP>/$MYPUBIP/g" /var/www/owlh/conf/ui.conf
service httpd restart
