#!/bin/bash
if ! yum list installed tcpreplay ; then 
    if ! yum list installed epel-release ; then 
        sudo yum --enablerepo=extras install epel-release
        sudo yum install -y https://dl.fedoraproject.org/pub/epel/epel-release-latest-7.noarch.rpm
    fi
  sudo yum -y install tcpreplay
fi

mkdir -p /usr/local/owlh/src/owlhnode/conf/certs /usr/local/owlh/bin

openssl req -newkey rsa:4096 -days 3650 -nodes -x509 \
    -subj "/C=ES/ST=VLC/L=VLC/O=OwlH/CN=softwareTap" \
    -keyout /usr/local/owlh/src/owlhnode/conf/certs/ca.key \
    -out /usr/local/owlh/src/owlhnode/conf/certs/ca.crt
cat /usr/local/owlh/src/owlhnode/conf/certs/ca.key /usr/local/owlh/src/owlhnode/conf/certs/ca.crt > /usr/local/owlh/src/owlhnode/conf/certs/ca.pem
chmod +600 /usr/local/owlh/src/owlhnode/conf/certs/*

cat > /usr/local/owlh/src/owlhnode/conf/stap-init.conf <<\EOF
INTERFACE="owlh"
PORT="50010"
CERT="/usr/local/owlh/src/owlhnode/conf/certs/ca.pem"
EOF

cat >> /etc/inittab << \EOF
owlhstapserver:2345:respawn:/usr/local/owlh/bin/manage-stap.sh
EOF

cat > /etc/init.d/owlhstapserver << \EOF
#!/bin/sh

# Copyright (C) 2019, OwlH.net
# OwlH Stap Client: controls software tap service
# Author:       owlh team <support@olwh.net>
#
# chkconfig: 2345 99 15
# description: starts and stop OwlH Sorfware TAP client
#

# Source function library.
export LANG=C

start() {
    echo -n "Starting OwlH STAP Server: "
    /usr/local/owlh/bin/manage-stap.sh start > /dev/null
    RETVAL=$?
    if [ $RETVAL -eq 0 ]; then
        echo "success"
    else
        echo "failure"
    fi
    echo
    return $RETVAL
}

stop() {
    echo -n "Stopping OwlH STAP Server: "
    /usr/local/owlh/bin/manage-stap.sh stop > /dev/null
    RETVAL=$?
    if [ $RETVAL -eq 0 ]; then
        echo "success"
    else
        echo "failure"
    fi
    echo
    return $RETVAL
}

status() {
    /usr/local/owlh/bin/manage-stap.sh status
    RETVAL=$?
    return $RETVAL
}

case "$1" in
start)
    start
    ;;
stop)
    stop
    ;;
restart)
    stop
    start
    ;;
status)
    status
    ;;
*)
    echo "*** Usage: owlhstapserver {start|stop|restart|status}"
    exit 1
esac

exit $?
EOF

chmod +x /etc/init.d/owlhstapserver

cat > /usr/local/owlh/bin/manage-stap.sh <<\EOF
#!/bin/bash
case "$1" in
start)
  source /usr/local/owlh/src/owlhnode/conf/stap-init.conf
  /usr/bin/socat -d OPENSSL-LISTEN:$PORT,reuseaddr,pf=ip4,fork,cert=$CERT,verify=0 SYSTEM:"tcpreplay -t -i $INTERFACE -" >> /dev/null 2>&1 &
  ;;
stop)
  if [ $(pidof socat) ] ; then
     kill -9 $(pidof socat)
     kill -9 $(pidof tcpreplay)
  fi
  ;;
status)
  echo -n "OwlH STAP Server status -> "
  if [ $(pidof socat) ] ; then
     echo -e "\e[92mRunning\e[0m"
     exit 0
  else
     echo -e "\e[91mNot running\e[0m"
     exit 1
  fi
esac

exit $?


EOF

chmod +x /usr/local/owlh/bin/manage-stap.sh

chkconfig --add owlh-stap
service owlhstapserver start
