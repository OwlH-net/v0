# Zeek

# Main packages 
if ! yum list installed epel-release ; then 
    sudo yum --enablerepo=extras install epel-release
    sudo yum install -y https://dl.fedoraproject.org/pub/epel/epel-release-latest-7.noarch.rpm
fi
yum -y install wget git
yum -y install jq openssl-devel PyYAML lz4-devel gcc libpcap-devel pcre-devel libyaml-devel file-devel zlib-devel jansson-devel nss-devel libcap-ng-devel libnet-devel tar make libnetfilter_queue-devel lua-devel cmake make gcc-c++ flex bison python-devel swig 

# ZEEK
cd /tmp
git clone --recursive https://github.com/zeek/zeek

cd zeek
./configure
make 
make install

if [ ! -d "/usr/local/zeek" ]; then
    echo -e "\e[91mThere was a problem installing Zeek, /usr/local/zeek path doesn't exist\e[0m"
    exit 1
fi


sed -i 's/eth0/owlh/g' /usr/local/zeek/etc/node.cfg

cat >> /usr/local/zeek/share/zeek/local.zeek <<\EOF
@include policy/tuning/json-logs.zeek
@include owlh.zeek
EOF

cat >> /usr/local/zeek/share/zeek/owlh.zeek <<\EOF
redef record DNS::Info += {
    bro_engine:    string    &default="DNS"    &log;
};
redef record Conn::Info += {
    bro_engine:    string    &default="CONN"    &log;
};
redef record Weird::Info += {
    bro_engine:    string    &default="WEIRD"    &log;
};
redef record SSL::Info += {
    bro_engine:    string    &default="SSL"    &log;
};
redef record SSH::Info += {
    bro_engine:    string    &default="SSH"    &log;
};
EOF



chkconfig --add owlhzeek
/usr/local/zeek/bin/zeekctl deploy

(sudo crontab -l ; echo "*/5 * * * * /usr/local/zeek/bin/zeekctl cron ") | crontab -



