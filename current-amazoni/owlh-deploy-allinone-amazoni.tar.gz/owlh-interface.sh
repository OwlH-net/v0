if ! yum list installed tcpreplay ; then 
    if ! yum list installed epel-release ; then 
        sudo yum --enablerepo=extras install epel-release
        sudo yum install -y https://dl.fedoraproject.org/pub/epel/epel-release-latest-7.noarch.rpm
    fi
	sudo yum -y install tcpreplay
fi
sudo echo 'install dummy /sbin/modprobe --ignore-install dummy' > /etc/modprobe.d/dummy.conf

sudo echo "
NAME=owlh
DEVICE=owlh
ONBOOT=yes
TYPE=Ethernet
NM_CONTROLLED=no
" > /etc/sysconfig/network-scripts/ifcfg-dummy

sudo /sbin/modprobe --ignore-install dummy
#sudo /sbin/ip link set name owlh dev dummy0
sudo /sbin/ip link set dev owlh mtu 56536
sudo ifup owlh
sudo echo "NOZEROCONF=yes" >> /etc/sysconfig/network
