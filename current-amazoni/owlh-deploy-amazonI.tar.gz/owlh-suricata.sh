# Suricata

# Main packages 
yum -y install epel-release wget git
yum -y install jq openssl-devel PyYAML lz4-devel gcc libpcap-devel pcre-devel libyaml-devel file-devel zlib-devel jansson-devel nss-devel libcap-ng-devel libnet-devel tar make libnetfilter_queue-devel lua-devel cmake make gcc-c++ flex bison python-devel swig 

# SURICATA
cd /tmp
wget https://www.openinfosecfoundation.org/download/suricata-4.1.4.tar.gz
tar xzvf suricata-4.1.4.tar.gz
cd /tmp/suricata-4.1.4
./configure --libdir=/usr/lib64 --prefix=/usr --sysconfdir=/etc --localstatedir=/var --enable-nfqueue --enable-lua
make
make install
make install-conf

if [ ! -d "/etc/suricata" ]; then
    echo -e "\e[91mThere was a problem installing Suricata, /etc/suricata path doesn't exist\e[0m"
    exit 1
fi

mkdir -p /etc/suricata/rules
cd /etc/suricata/rules
wget http://repo.owlh.net/current/owlh.rules

cat >> /etc/suricata/suricata.yaml <<\EOF
include: owlh.yaml
EOF

cat > /etc/suricata/owlh.yaml <<\EOF
%YAML 1.1
---

outputs:
- eve-log:
  enabled: yes
  filetype: regular #regular|syslog|unix_dgram|unix_stream|redis
  filename: eve.json
  pcap-file: false
  xff:
    enabled: yes
    mode: extra-data
    deployment: reverse
    header: X-Forwarded-For
  types:
    - alert:
        payload: yes             # enable dumping payload in Base64
        payload-buffer-size: 4kb # max size of payload buffer to output in eve-log
        payload-printable: yes   # enable dumping payload in printable (lossy) format
        packet: yes              # enable dumping of packet (without stream segments)
        http-body: yes           # enable dumping of http body in Base64
        http-body-printable: yes # enable dumping of http body in printable format
        # metadata: no             # enable inclusion of app layer metadata with alert. Default yes
        tagged-packets: yes
    - http:
        extended: yes     # enable this for extended logging information
        #custom: [Accept-Encoding, Accept-Language, Authorization]
    - dns:
        version: 2
        #enabled: no
        #requests: no
        #responses: no
        #formats: [detailed, grouped]
        #types: [a, aaaa, cname, mx, ns, ptr, txt]
    - tls:
        extended: yes     # enable this for extended logging information
        #session-resumption: no
        #custom: [subject, issuer, session_resumed, serial, fingerprint, sni, version, not_before, not_after, certificate, chain, ja3]
    - files:
        force-magic: no   # force logging magic on all logged files
        #force-hash: [md5]
    - ssh
    - stats:
        totals: yes       # stats for all threads merged together
        threads: no       # per thread stats
        deltas: no        # include delta values
    - flow
    #- netflow



default-rule-path: /etc/suricata/rules
rule-files:
 - owlh.rules
EOF

cat > /usr/local/owlh/src/owlhnode/conf/suricata-init.conf <<\EOF
INTERFACE="owlh"
EOF


cat >> /etc/inittab << \EOF
owlhsuricata:2345:respawn:/usr/local/owlh/bin/manage-suricata.sh
EOF

cat > /etc/init.d/owlhsuricata << \EOF
#!/bin/sh

# Copyright (C) 2019, OwlH.net
# OwlH suricata: controls suricata Service
# Author:       owlh team <support@olwh.net>
#
# chkconfig: 2345 99 15
# description: starts and stop suricata
#

# Source function library.
export LANG=C

start() {
    echo -n "Starting OwlH Suricata: "
    /usr/local/owlh/bin/manage-suricata.sh start > /dev/null 
    RETVAL=$?
    if [ $RETVAL -eq 0 ]; then
        echo "success"
    else
        echo "failure"
    fi
    echo
    return $RETVAL
}

stop() {
    echo -n "Stopping OwlH Suricata : "
    /usr/local/owlh/bin/manage-suricata.sh stop > /dev/null
    RETVAL=$?
    if [ $RETVAL -eq 0 ]; then
        echo "success"
    else
        echo "failure"
    fi
    echo
    return $RETVAL
}

status() {
    /usr/local/owlh/bin/manage-suricata.sh status
    RETVAL=$?
    return $RETVAL
}

case "$1" in
start)
    start
    ;;
stop)
    stop
    ;;
restart)
    stop
    start
    ;;
status)
    status
    ;;
*)
    echo "*** Usage: owlhsuricata {start|stop|restart|status}"
    exit 1
esac

exit $?
EOF

chmod +x /etc/init.d/owlhsuricata

cat > /usr/local/owlh/bin/manage-suricata.sh <<\EOF
#!/bin/bash
case "$1" in
start)
  source /usr/local/owlh/src/owlhnode/conf/suricata-init.conf
  /usr/bin/suricata -c /etc/suricata/suricata.yaml -i $INTERFACE >> /dev/null 2>&1 &
  ;;
stop)
  if [ $(pidof suricata) ] ; then
     kill -9 $(pidof suricata)
  fi
  ;;
status)
  echo -n "OwlH Suricata status -> "
  if [ $(pidof suricata) ] ; then
     echo -e "\e[92mRunning\e[0m"
     exit 0
  else
     echo -e "\e[91mNot running\e[0m"
     exit 1
  fi
esac

exit $?


EOF

chmod +x /usr/local/owlh/bin/manage-suricata.sh

chkconfig --add owlhsuricata
chkconfig owlhsuricata on
service owlhsuricata start 
