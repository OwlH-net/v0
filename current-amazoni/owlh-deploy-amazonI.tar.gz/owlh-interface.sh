#interface owlh for amazon linux I
if ! yum list installed tcpreplay ; then 
    sudo yum install -y https://dl.fedoraproject.org/pub/epel/epel-release-latest-7.noarch.rpm
    sudo yum -y install tcpreplay
fi

sudo echo "
/sbin/ip link add dummy0 type dummy
/sbin/ip link set name owlh dev dummy0
/sbin/ip link set dev owlh mtu 56536
/sbin/ip link set owlh up
" > /etc/rc3.d/S99local

/sbin/ip link add dummy0 type dummy
/sbin/ip link set name owlh dev dummy0
/sbin/ip link set dev owlh mtu 56536
/sbin/ip link set owlh up